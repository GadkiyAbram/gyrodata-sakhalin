<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<section>
    <div class="container">
        <div class="user signinBx">
            <div class="imgBx"><img src="surveying-left.jpg"></div>
            <div class="formBx">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <h2>Log In</h2>

                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="submit" name="" value="Login">

                    <p class="signup">Don't have an account ? <a href="#" onclick="toggleForm();">Send Request</a></p>
                </form>
            </div>
        </div>
        <div class="user signupBx">
            <div class="formBx">
                <form method="POST" action="<?php echo e(route('login.request')); ?>">

                    <?php echo csrf_field(); ?>
                    <h2>Request an account</h2>
                    <input type="text" name="name" placeholder="First Name">
                    <input type="text" name="lastname" placeholder="Last Name">
                    <input type="email" name="email" placeholder="Email">
                    <input type="submit" name="" value="Request">
                    <p class="signup">Already with Us ? <a href="#" onclick="toggleForm();">Log In</a></p>
                </form>
            </div>
            <div class="imgBx"><img src="surveying-right.jpg"></div>
        </div>
    </div>
</section>
<script type="text/javascript">
    function toggleForm(){
        var container = document.querySelector('.container');
        container.classList.toggle('active');
    }

    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
        alert(msg);
    }
</script>
</body>
<?php /**PATH C:\Users\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/loginnew.blade.php ENDPATH**/ ?>