<html>

<head>
	<style>
		.conditionNew {
			color: forestgreen;
		}
		.conditionUsed {
			color: red;
		}
	</style>
</head>

<body>
<div class="pl-3 pr-3">
	<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="pl-4 pr-4">

	<div class="d-flex justify-content-between align-items-baseline">

		<div>
			<h3>Lithium Batteries</h3>
			Total batteries: <?php echo e($batteries->count()); ?>


		</div>
		<div>
			<a href="/batteries/create">Add New Battery</a>
		</div>

	</div>


	<table class="table table-striped">
		<thead>
		<tr>
			<th scope="col">Condition</th>
			<th scope="col">Serial 1</th>
			<th scope="col">Serial 2</th>
			<th scope="col">Serial 3</th>
			<th scope="col">Production Date</th>
			<th scope="col">Container</th>
			<th scope="col">Job assigned</th>
			<th scope="col">Comment</th>
			<th scope="col">Action</th>
		</tr>
		</thead>
		<?php $__currentLoopData = $batteries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $battery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tbody>
			<tr>
				<th scope="row">

					<?php if($battery->condition === '1'): ?>
						<span class="conditionNew"><?php echo e($battery->getConditionOptions($battery->condition)); ?></span>
					<?php elseif($battery->condition === '0'): ?>
						<span class="conditionUsed"><?php echo e($battery->getConditionOptions($battery->condition)); ?></span>
					<?php endif; ?>

				</th>
				<td><a href="#"><?php echo e($battery->serialOne); ?></a></td>
				<td><?php echo e($battery->serialTwo ?? 'N/A'); ?></td>
				<td><?php echo e($battery->serialThree); ?></td>
				<td><?php echo e($battery->date); ?></td>
				<td><?php echo e($battery->container); ?></td>
				<td><?php echo e($battery->job_assigned); ?></td>
				<td><?php echo e($battery->comment); ?></td>
				<td><a href="#">Edit</a></td>
			</tr>
			</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</div>

</body>

</html><?php /**PATH C:\Users\Aleksandr.Abramovski\gyrodata-sakhalin\resources\views/batteries/index.blade.php ENDPATH**/ ?>