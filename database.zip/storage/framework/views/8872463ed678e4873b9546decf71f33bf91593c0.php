<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="row">
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Condition</th>
            <th scope="col">Serial 1</th>
            <th scope="col">Serial 2</th>
            <th scope="col">Serial 3</th>
            <th scope="col">Production Date</th>
            <th scope="col">Invoice</th>
            <th scope="col">CCD</th>
            <th scope="col">Container</th>
            <th scope="col">Comment</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <?php $__currentLoopData = $batteries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $battery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>
                <th scope="row">

                    <?php if($battery->BatteryCondition === 'New'): ?>
                        <span class="conditionNew"><?php echo e($battery->BatteryCondition); ?></span>
                    <?php elseif($battery->BatteryCondition === 'Used'): ?>
                        <span class="conditionUsed"><?php echo e($battery->BatteryCondition); ?></span>
                    <?php endif; ?>

                </th>
                <td><a href="/batteries/<?php echo e($battery->Id); ?>"><?php echo e($battery->SerialOne); ?></a></td>
                <td><?php echo e($battery->SerialTwo ?? 'N/A'); ?></td>
                <td><?php echo e($battery->SerialThr); ?></td>
                <td><?php echo e($battery->Arrived); ?></td>
                <td><?php echo e($battery->Invoice); ?></td>
                <td><?php echo e($battery->CCD); ?></td>
                <td><?php echo e($battery->Container); ?></td>
                <td><?php echo e($battery->Comment); ?></td>
                <td><a href="/batteries/<?php echo e($battery->Id); ?>/edit">Edit</a></td>
            </tr>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</body>
</html>
<?php /**PATH E:\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/batteries/data.blade.php ENDPATH**/ ?>