<html>

<head>

</head>

<body>
<div class="pl-3 pr-3">

	<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="pl-4 pr-4">

	<div class="d-flex justify-content-between align-items-baseline">

		<div class="align-content-center pr-3">
			<div class="d-flex justify-content-between align-items-baseline">
				<a href="/tools">Go back</a>
				<h5 class="pl-2"><?php echo e($tool->tool_number); ?></h5>
			</div>
		</div>
		<div>
			<a href="#">Edit Tool</a>
		</div>

	</div>

	<div class="row">
		<div class="col-5">
			<p><strong>Type: </strong><?php echo e($tool->tool_type); ?></p>
			<p><strong>Asset: </strong><?php echo e($tool->tool_number); ?></p>
			<p><strong>Arrived: </strong><?php echo e($tool->tool_arrived); ?></p>
			<p><strong>Demob: </strong><?php echo e($tool->tool_demob); ?></p>
			<p><strong>Invoice: </strong><?php echo e($tool->tool_invoice); ?></p>
			<p><strong>Custom Decl: </strong><?php echo e($tool->tool_ccd); ?></p>
			<p><strong>Description RUS: </strong><?php echo e($tool->tool_desc_rus); ?></p>
			<p><strong>CCD Position: </strong><?php echo e($tool->tool_ccd_pos); ?></p>
			<p><strong>Tool Location: </strong><?php echo e($tool->tool_location); ?></p>
			<p><strong>Tool Last RT: </strong><?php echo e($tool->tool_last_rt); ?></p>
			<p><strong>Comment: </strong><?php echo e($tool->tool_comment); ?></p>

		</div>

		<div class="col-7">
			<?php if($tool->tool_type === 'GWD GDP Section' ||
				$tool->tool_type === 'GWD Modem Section' ||
				$tool->tool_type === 'GWD Battery BullPlug'): ?>

				<p><strong>Total Circulation: </strong>
					<?php echo e($tool->tool_circHrs); ?> hrs,	<?php echo e($circ_remains); ?> until PM
				</p>

				<table class="table table-striped">
					<thead>
					<tr>
						<th scope="col">Job involved</th>
						<th scope="col">Circ Hrs</th>
					</tr>
					</thead>
					<?php $__currentLoopData = $jobs_involved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tbody>
						<tr>
							<td><?php echo e($job->jobNumber); ?></td>
							<td><?php echo e($job->toolCircHrs); ?></td>
						</tr>
						</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			<?php endif; ?>


			<?php if($tool->image): ?>
				<div class="row col-12">
					<img src="<?php echo e(asset('storage/' . $tool->image)); ?>"
						 class="img-thumbnail">
				</div>
			<?php endif; ?>

	</div>



	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</div>

</body>

</html><?php /**PATH C:\Users\Aleksandr.Abramovski\gyrodata-sakhalin\resources\views/tools/show.blade.php ENDPATH**/ ?>