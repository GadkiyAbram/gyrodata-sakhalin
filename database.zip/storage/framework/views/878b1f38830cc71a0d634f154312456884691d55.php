<html>

<head>

</head>

<body>
<div class="pl-3 pr-3">
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="pl-4 pr-4">

    <div class="d-flex justify-content-between align-items-baseline">

        <div class="align-content-center pr-3">
            <div class="d-flex justify-content-between align-items-baseline">
                <a href="/batteries">Go back</a>
                <h5 class="pl-2"><?php echo e($battery['SerialOne']); ?></h5>
            </div>
        </div>
        <div>
            <a href="/batteries/<?php echo e($battery['Id']); ?>/edit">Edit Battery</a>
        </div>

    </div>

    <div class="row">
        <div class="col-5">
            <p><strong>Condition: </strong><?php echo e($battery['BatteryCondition']); ?></p>
            <p><strong>Arrived: </strong><?php echo e($battery['Arrived']); ?></p>
            <p><strong>Box Number: </strong><?php echo e($battery['BoxNumber']); ?></p>
            <p><strong>Serial 2: </strong><?php echo e($battery['SerialTwo']); ?></p>
            <p><strong>Serial 3: </strong><?php echo e($battery['SerialThr']); ?></p>
            <p><strong>CCD: </strong><?php echo e($battery['CCD']); ?></p>
            <p><strong>Invoice: </strong><?php echo e($battery['Invoice']); ?></p>
            <p><strong>Location: </strong><?php echo e($battery['BatteryStatus']); ?></p>
            <p><strong>Container: </strong><?php echo e($battery['Container']); ?></p>
            <p><strong>Comment: </strong><?php echo e($battery['Comment']); ?></p>
        </div>




        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </div>
</div>

</body>

</html>
<?php /**PATH C:\Users\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/batteries/show.blade.php ENDPATH**/ ?>