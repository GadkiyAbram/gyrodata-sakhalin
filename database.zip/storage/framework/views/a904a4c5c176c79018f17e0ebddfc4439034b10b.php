<html>

<head>
	<style>
		.conditionNew {
			color: forestgreen;
		}
		.conditionUsed {
			color: red;
		}
	</style>
</head>

<body>
<div class="pl-3 pr-3">
	<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="pl-4 pr-4">

	<div class="d-flex justify-content-between align-items-baseline">

		<div>
			<h3>Lithium Batteries</h3>
			Total batteries: <?php echo e($count); ?>


		</div>
		<div>
			<a href="/batteries/create">Add New Battery</a>
		</div>

	</div>


	<table class="table table-striped">
		<thead>
		<tr>
			<th scope="col">Condition</th>
			<th scope="col">Serial 1</th>
			<th scope="col">Serial 2</th>
			<th scope="col">Serial 3</th>
			<th scope="col">Production Date</th>
			<th scope="col">Container</th>
			<th scope="col">Comment</th>
			<th scope="col">Action</th>
		</tr>
		</thead>

		
			
			
				

					
						
					
						
					

				
				
				
				
				
				
				
				
			
			
		

		<?php for($i = 0; $i < count($batteries); $i++): ?>
			<tbody>
			<tr>
				<th scope="row">

					<?php if($batteries[$i]->BatteryCondition === 'New'): ?>
						<span class="conditionNew"><?php echo e($batteries[$i]->BatteryCondition); ?></span>
					<?php elseif($batteries[$i]->BatteryCondition === 'Used'): ?>
						<span class="conditionUsed"><?php echo e($batteries[$i]->BatteryCondition); ?></span>
					<?php endif; ?>

				</th>
				<td><a href="#"><?php echo e($batteries[$i]->SerialOne); ?></a></td>
				<td><?php echo e($batteries[$i]->SerialTwo ?? 'N/A'); ?></td>
				<td><?php echo e($batteries[$i]->SerialThr); ?></td>
				<td><?php echo e($batteries[$i]->Arrived); ?></td>
				<td><?php echo e($batteries[$i]->Container); ?></td>
				<td><?php echo e($batteries[$i]->Comment); ?></td>
				<td><a href="#">Edit</a></td>
			</tr>
			</tbody>
		<?php endfor; ?>

	</table>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</div>

</body>

</html><?php /**PATH C:\Users\Aleksandr.Abramovski\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/batteries/index.blade.php ENDPATH**/ ?>