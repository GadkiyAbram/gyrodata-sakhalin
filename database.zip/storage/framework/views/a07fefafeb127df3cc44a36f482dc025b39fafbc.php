<html>

<head>

</head>

<body>
<div class="pl-3 pr-3">

	<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="pl-4 pr-4">

	<div>
		<div>
			<h3>Token</h3>
		</div>
		<form action="<?php echo e(route('preferences.store')); ?>" method="post" enctype="multipart/form-data">

			<div>
				<label for="User" class="col-form-label">Username</label>
				<div>
					<input type="text" class="form-control" name="User" placeholder="user1">
				</div>
				<label for="Password" class="col-form-label">Password</label>
				<div>
					<input type="text" class="form-control" name="Password" placeholder="pass1">
				</div>

				<div>
					<button type="submit" class="btn btn-primary">Get Token</button>
				</div>

			</div>
			<?php echo csrf_field(); ?>
		</form>

	</div>



	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</div>

</body>

</html><?php /**PATH C:\Users\Aleksandr.Abramovski\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/token/index.blade.php ENDPATH**/ ?>