<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="row">
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Job Number</th>
            <th scope="col">Client</th>
            <th scope="col">Tool</th>
            <th scope="col">Modem</th>
            <th scope="col">BBP</th>
            <th scope="col">Battery</th>
            <th scope="col">Engineer 1</th>
            <th scope="col">Engineer 2</th>
            <th scope="col">Circ Hrs</th>
            <th scope="col">Container</th>
            <th scope="col">Comment</th>
            <th scope="col">###</th>
        </tr>
        </thead>
        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>
                <th scope="row"><a href="/jobs/<?php echo e($job->JobNumber); ?>"><?php echo e($job->JobNumber); ?></a></th>
                <td><?php echo e($job->ClientName); ?></td>
                <td><?php echo e($job->GDP); ?></td>
                <td><?php echo e($job->Modem); ?></td>
                <td><?php echo e($job->Bullplug); ?></td>
                <td><?php echo e($job->Battery); ?></td>
                <td><?php echo e($job->EngineerOne); ?></td>
                <td><?php echo e($job->EngineerTwo); ?></td>
                <td><?php echo e($job->CirculationHours); ?></td>
                <td><?php echo e($job->Container); ?></td>
                <td><?php echo e($job->Comment); ?></td>
                <td><a href="/jobs/<?php echo e($job->JobNumber); ?>/edit">Edit</a></td>
            </tr>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</body>
</html>
<?php /**PATH C:\Users\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/jobs/data.blade.php ENDPATH**/ ?>