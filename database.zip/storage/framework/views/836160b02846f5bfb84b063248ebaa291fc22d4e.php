<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="row">
    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Tool Type</th>
            <th scope="col">Tool A/N</th>
            <th scope="col">Arrived</th>
            <th scope="col">CCD</th>
            <th scope="col">Invoice</th>
            <th scope="col">Location</th>
            <th scope="col">Circ Hrs</th>
            <th scope="col">Comment</th>
            <th scope="col">###</th>
        </tr>
        </thead>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>
                <td><?php echo e($item->Item); ?></td>
                <td><a href="/tools/<?php echo e($item->Id); ?>"><?php echo e($item->Asset); ?></a></td>
                <td><?php echo e($item->Arrived); ?></td>
                <td><?php echo e($item->CCD); ?></td>
                <td><?php echo e($item->Invoice); ?></td>
                <td><?php echo e($item->ItemStatus); ?></td>
                <td><?php echo e($item->Circulation); ?></td>
                <td><?php echo e($item->Comment); ?></td>
                <td><a href="/tools/<?php echo e($item->Id); ?>/edit">Edit</a></td>
            </tr>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</body>
</html>
<?php /**PATH C:\Users\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/tools/data.blade.php ENDPATH**/ ?>