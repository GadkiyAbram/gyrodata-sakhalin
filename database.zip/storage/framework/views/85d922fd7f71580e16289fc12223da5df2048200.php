<!DOCTYPE html>
<html lang="en" style="background-color: #a2a6ab">











<?php echo $__env->make('loginnew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/auth/login.blade.php ENDPATH**/ ?>