<html>

<head>

</head>

<body>
<div class="pl-3 pr-3">

	<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="pl-4 pr-4">

	<div class="d-flex justify-content-between align-items-baseline">

		<div class="align-content-center pr-3">
			<a href="/jobs">Go back</a>
		</div>
		<div>
			<h5><?php echo e($job->jobNumber); ?></h5>
		</div>
		<div>
			<a href="#">Edit Job</a>
		</div>

	</div>

	<div class="row">
		<div class="col-4">
			<p><strong>GWD Tool: </strong><?php echo e($job->toolNumber); ?></p>
			<p><strong>Modem: </strong><?php echo e($job->modemNumber); ?></p>
			<p><strong>GWD BBP: </strong><?php echo e($job->bbpNumber); ?></p>
			<p><strong>Battery: </strong><?php echo e($battery_serialOne); ?></p>
			<p><strong>First Eng: </strong><?php echo e(\App\Engineer::where('id', $job->engFirst)->first()->name ?? 'Not assigned'); ?></p>
			<p><strong>Second Eng: </strong><?php echo e(\App\Engineer::where('id', $job->engSecond)->first()->name ?? 'Not assigned'); ?></p>
			<p><strong>Eng1 Arrived: </strong><?php echo e($job->eng1ArrRig); ?></p>
			<p><strong>Eng2 Arrived: </strong><?php echo e($job->eng2ArrRig); ?></p>

		</div>
		<div class="col-6">
			<p><strong>Eng1 Depart: </strong><?php echo e($job->eng1DepRig); ?></p>
			<p><strong>Eng2 Depart: </strong><?php echo e($job->eng2DepRig); ?></p>
			<p><strong>Container: </strong><?php echo e($job->container); ?></p>
			<p><strong>Container arrived: </strong><?php echo e($job->containerArrRig); ?></p>
			<p><strong>Container depart: </strong><?php echo e($job->containerDepRig); ?></p>
			<p><strong>Circ Hrs: </strong><?php echo e($job->toolCircHrs); ?></p>
			<p><strong>Comment: </strong><?php echo e($job->comment); ?></p>
		</div>
	</div>



	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</div>

</body>

</html><?php /**PATH C:\Users\Aleksandr.Abramovski\PROJECTS\PHP_PROJECTS\gyrodata-sakhalin\resources\views/jobs/show.blade.php ENDPATH**/ ?>