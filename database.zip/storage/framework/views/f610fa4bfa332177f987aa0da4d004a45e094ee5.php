<html>

<head>

</head>

<body>
<div class="pl-3 pr-3">

	<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


<div class="pl-4 pr-4">

	<div class="d-flex justify-content-between align-items-baseline">

		<div>
			<h3>Tools Tracking</h3>
		</div>
		<div>
			<a href="/tools/create">Add Tool</a>
		</div>

	</div>


	<table class="table table-striped">
		<thead>
		<tr>
			<th scope="col">Tool Type</th>
			<th scope="col">Tool A/N</th>
			<th scope="col">Arrived</th>
			<th scope="col">Demob</th>
			<th scope="col">CCD</th>
			<th scope="col">Location</th>
			<th scope="col">Circ Hrs</th>
			<th scope="col">Comment</th>
			<th scope="col">###</th>
		</tr>
		</thead>
		<?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tbody>
			<tr>
				<td><?php echo e($tool->tool_type); ?></td>
				<td><a href="/tools/<?php echo e($tool->id); ?>"><?php echo e($tool->tool_number); ?></a></td>
				<td><?php echo e($tool->tool_arrived); ?></td>
				<td><?php echo e($tool->tool_demob); ?></td>
				<td><a href="#"><?php echo e($tool->tool_ccd); ?></a></td>
				<td><?php echo e($tool->tool_location); ?></td>
				<td><?php echo e($tool->tool_circHrs); ?></td>
				<td><?php echo e($tool->tool_comment); ?></td>
				<td><a href="#">Edit</a></td>
			</tr>
			</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</div>

</body>

</html><?php /**PATH C:\Users\Aleksandr.Abramovski\gyrodata-sakhalin\resources\views/tools/index.blade.php ENDPATH**/ ?>