$( function show_hide() {
    var click = document.getElementById("drop-content");
    if (click.style.display === "none") {
        click.style.display = "block";
    }
    // else {
    //     click.style.display = "none";
    // }
    window.onclick = function(event) {
        click.style.display = "none";
    }
});
