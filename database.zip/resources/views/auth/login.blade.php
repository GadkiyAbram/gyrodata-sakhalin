<!DOCTYPE html>
<html lang="en" style="background-color: #a2a6ab">
{{--<head>--}}
{{--    <meta charset="utf-8">--}}
{{--    <meta name="viewport" content="width=device-width, initial-scale=1.0">--}}
{{--    <meta http-equiv="x-ua-compatible" content="ie=edge">--}}

{{--    <meta name="csrf-token" content="{{ csrf_token() }}">--}}
{{--    <link rel="stylesheet" href="/css/style.css">--}}

{{--</head>--}}
{{--@extends('layouts.app')--}}

@include('loginnew')
