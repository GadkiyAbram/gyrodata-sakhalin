<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsersPending extends Model
{
    protected $table = 'users_pendings';

    protected $guarded = [];
}
