<?php
/**
 * Created by PhpStorm.
 * User: Aleksandr.Abramovski
 * Date: 13/02/2020
 * Time: 10:45
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Component extends Model
{
    protected $guarded = [];
}