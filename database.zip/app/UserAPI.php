<?php
/**
 * Created by PhpStorm.
 * User: Aleksandr.Abramovski
 * Date: 19/02/2020
 * Time: 10:52
 */

namespace App;


class UserAPI
{
    protected $guarded = [];
}